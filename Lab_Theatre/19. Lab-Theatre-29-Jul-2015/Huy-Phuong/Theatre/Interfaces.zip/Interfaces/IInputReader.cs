﻿namespace TheatreSystem.Interfaces
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}
