﻿namespace TheatreSystem.Interfaces
{
    public interface IExecutable
    {
        string Execute();
    }
}
