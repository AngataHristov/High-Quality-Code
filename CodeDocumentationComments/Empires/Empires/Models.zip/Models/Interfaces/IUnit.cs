﻿
namespace Empires.Models.Interfaces
{
    public interface IUnit
    {
        int Health { get; }

        int AttackDamage { get; }
    }
}
