﻿

namespace Empires.Models.Interfaces
{
    using Enumerations;

    public interface IResource
    {
        ResourceTypes Type { get; }

        int Quantity { get; }
    }
}
