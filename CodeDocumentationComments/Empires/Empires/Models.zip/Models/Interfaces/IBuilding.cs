﻿
namespace Empires.Models.Interfaces
{
    using System.Collections.Generic;

    using Empires.Interfaces;

    public interface IBuilding
    {
        IEnumerable<IUnit> Units { get; }

        IEnumerable<IResource> Resources { get; }

        void AddUnit(IUnit unit);

        void AddResource(IResource resource);

        int CycleCounter { get; }

        int ResourceCycle { get; }

        int UnitCycle { get; }

        IEngine Engine { get; }

        void Update();
    }
}
