﻿
namespace Empires.Interfaces
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}
