﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empires.Interfaces
{
    public interface IEngine
    {
        ICommandManager CommandManager { get; }

        IInputReader Reader { get; }

        IOutputWriter Writer { get; }

        IDataBase DB { get; }

        void Run();

        void Stop();
    }
}
