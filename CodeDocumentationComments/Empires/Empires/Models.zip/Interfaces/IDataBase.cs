﻿
namespace Empires.Interfaces
{
    using System.Collections.Generic;
    using Enumerations;
    using Models.Interfaces;

    public interface IDataBase
    {
        IEnumerable<IBuilding> AllBuildings { get; }

        IEnumerable<IUnit> AllUnits { get; }

        IDictionary<ResourceTypes, int> Resources { get; }

        IDictionary<UnitTypes, int> Units { get; }

        void AddUnit(IUnit unit);

        void AddBuilding(IBuilding building);
    }
}
