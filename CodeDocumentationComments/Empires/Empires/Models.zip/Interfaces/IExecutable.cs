﻿
namespace Empires.Interfaces
{
    using Core.Engines;

    public delegate void OnRunningChanged(object sender, CommandEventArgs args);

    public interface IExecutable
    {
        void Execute();

        event OnRunningChanged OnExecuting;
    }
}
