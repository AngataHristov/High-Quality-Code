﻿
namespace Empires.Core.Commands
{
    using Interfaces;
    public class SkipCommand : CommandAbstract
    {
        public SkipCommand()
            : base(null)
        {

        }

        public override void Execute()
        {
        }
    }
}
