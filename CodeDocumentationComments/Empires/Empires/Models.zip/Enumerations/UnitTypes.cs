﻿
namespace Empires.Enumerations
{
    public enum UnitTypes
    {
        Archer,
        Swordsman
    }
}
