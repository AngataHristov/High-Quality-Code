﻿
namespace Empires.Enumerations
{
    public enum ResourceTypes
    {
        Steel,
        Gold
    }
}
