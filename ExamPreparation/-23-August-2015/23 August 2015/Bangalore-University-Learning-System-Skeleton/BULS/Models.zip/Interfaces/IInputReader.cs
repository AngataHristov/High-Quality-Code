﻿namespace BangaloreUniversityLearningSystem.Interfaces
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}
