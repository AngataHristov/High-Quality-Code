﻿namespace BangaloreUniversityLearningSystem.Enumerations
{
    public enum Role
    {
        Student,
        Lecturer
    }
}
