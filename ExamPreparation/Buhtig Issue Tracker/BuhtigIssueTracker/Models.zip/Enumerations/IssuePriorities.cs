﻿namespace BuhtigIssueTracker.Enumerations
{
    public enum IssuePriorities
    {
        Showstopper = 4,
        High = 3,
        Medium = 2,
        Low = 1
    }
}