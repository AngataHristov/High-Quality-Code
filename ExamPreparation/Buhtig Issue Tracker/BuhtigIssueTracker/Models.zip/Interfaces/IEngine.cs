﻿namespace BuhtigIssueTracker.Interfaces
{
   public interface IEngine
    {
        void Run();
    }
}