﻿namespace BuhtigIssueTracker.Interfaces
{
    public interface IInputReader
    {
        string ReadNextLine();
    }
}
