﻿namespace HotelBookingSystem.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}
