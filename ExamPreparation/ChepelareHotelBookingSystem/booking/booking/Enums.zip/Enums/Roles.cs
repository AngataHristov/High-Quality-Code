﻿namespace HotelBookingSystem.Enums
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
